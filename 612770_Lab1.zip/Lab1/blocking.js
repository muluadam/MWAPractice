console.log("1: Start");
const feb=require('./fibonacci');

console.log("2: Start");
